


#====================================
import numpy as np
X1 = np.array([0.8,0.6])
X2 = np.array([0.17,-0.98])
X3 = np.array([0.707,0.707])
X4 = np.array([0.34,-0.93])
X5 = np.array([0.6,0.8])
W1 = np.array([1,0])
W2 = np.array([0,-1])

W = [W1,W2]
X = [X1,X2,X3,X4,X5]

k = np.zeros(5)
k1 = np.ones(5)
c = 0
j = 0
while k1.all() != k.all():
    net1 = np.dot(W[0],X1)
    net2 = np.dot(W[1],X1)
    if net1 > net2:
        dw1 = 0.1*(X1-W[0])
        W[0] = W[0] + dw1
        k1 = 0
        if k[0] != k1:
            k[0] = k1
            k1 = k
    else:
        dw2 = 0.1*(X1-W[1])
        W[1] = W[1] +dw2
        k1 = 1
        if k[0] != k1:
            k[0] = k1
            k1= k
    net1 = np.dot(W[0],X2)
    net2 = np.dot(W[1],X2)
    if net1 > net2:
        dw1 = 0.1*(X2-W[0])
        W[0] = W[0] + dw1
        k1 = 0
        if k[1] != k1:
            k[1] = k1
            k1= k
    else:
        dw2 = 0.1*(X2-W[1])
        W[1] = W[1] +dw2
        k1 = 1
        if k[1] != k1:
            k[1] = k1
            k1 = k
    net1 = np.dot(W[0],X3)
    net2 = np.dot(W[1],X3)
    if net1 > net2:
        dw1 = 0.1*(X3-W[0])
        W[0] = W[0] + dw1
        k1 = 0
        if k[2] != k1:
            k[2] = k1
            k1 = k
    else:
        dw2 = 0.1*(X3-W[1])
        W[1] = W[1] +dw2
        k1 = 1
        if k[2] != k1:
            k[2] = k1
            k1 = k
    net1 = np.dot(W[0],X4)
    net2 = np.dot(W[1],X4)
    if net1 > net2:
        dw1 = 0.1*(X4-W[0])
        W[0] = W[0] + dw1
        k1 = 0
        if k[3] != k1:
            k[3] = k1
            k1= k
    else:
        dw2 = 0.1*(X4-W[1])
        W[1] = W[1] +dw2
        k1 = 1
        if k[3] != k1:
            k[3] = k1
            k1 = k
    net1 = np.dot(W[0],X5)
    net2 = np.dot(W[1],X5)
    if net1 > net2:
        dw_1 = 0.1*(X5-W[0])
        W[0] = W[0] + dw1
        k1 = 0
        if k[4] != k1:
            k[4] = k1
            k1 = k
    else:
        dw2 = 0.1*(X3-W[1])
        W[1] = W[1] +dw2
        k1 = 1
        if k[4] != k1:
            k[4] = k1
            k1 = k
    c += 1
print("Iterations = " ,c)
print(k1)
c1 = []
c2 = []
for i in range(len(k1)):
    if k1[i] == 1:
        c1.append(i+1)
    else:
        c2.append(i+1)
print("In C1 = ",c1)
print("In C2 = ",c2)   
#OUTPUT : 
#Iterations = 1
#[0. 1. 0. 1. 0.]
#In Cluster 1 =  [2, 4]
#In Cluster 2 =  [1, 3, 5]
