

import cv2
import numpy as np
from matplotlib import pyplot as plt

j = complex(0,1)

img_1 = cv2.imread('‪C:\\Users\\net comm0560\\Desktop\\123\\gray.jpg',0)  # Input Image
plt.subplot(2,2,1)
plt.imshow(img_1,cmap = 'gray')
plt.title('Input Image 1')

img_2 = cv2.imread('C:\\Users\\net comm0560\\Desktop\\123\\babbon.png',0)  # Input Image
plt.subplot(2,2,2)
plt.imshow(img_2,cmap = 'gray')
plt.title('Input Image 2')

[rows1,cols1] = img_1.shape
[rows2,cols2] = img_2.shape

rows = max(rows1,rows2)
cols = max(cols1,cols2)
print(rows)
print(cols)

img_1FFT = np.fft.fft2(img_1) # FFT of Images
img_2FFT = np.fft.fft2(img_2)

mag1 = np.abs(img_1FFT)
mag2 = np.abs(img_2FFT)
pha1 = np.angle(img_1FFT)
pha2 = np.angle(img_2FFT)

out1 = mag1*np.e**(j*pha2)
out2 = mag2*np.e**(j*pha1)

out1 = np.fft.ifft2(out1)
new_img1 = 20*np.log(np.abs(out1))

out2 = np.fft.ifft2(out2)
new_img2 = 20*np.log(np.abs(out2))

plt.subplot(2,2,3)
plt.imshow(new_img1,cmap = 'gray')
plt.title('Magnitude 1 & Phase 2')

plt.subplot(2,2,4)
plt.imshow(new_img2,cmap = 'gray')
plt.title('Magnitude 2 & Phase 1')

plt.show()
cv2.waitKey()






