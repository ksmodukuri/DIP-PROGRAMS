# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 20:56:09 2019

@author: net comm0560
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
img=cv2.imread("C:\\Users\\net comm0560\\Desktop\\123\\2.jpg")
cv2.imshow('lena',img)
a=np.fft.fft2(img)
fshift = np.fft.fftshift(a)
mag_spec=20*np.log(np.abs(fshift))
phase_spec=np.angle(fshift)

img1=cv2.imread("suk1.png")
cv2.imshow('block',img1)
b=np.fft.fft2(img1)
fshift1 = np.fft.fftshift(b)
mag_spec1=20*np.log(np.abs(fshift1))
phase_spec1=np.angle(fshift)

img3=abs(a)* math.exp(1j*np.angle(b))
combined=np.multiply(np.abs(a),np.exp(1j*np.angle(b)))
img3=np.real(np.fft.ifft2(combined))
img3=np.abs(img3)
plt.imshow('img3',cmap='gray')
