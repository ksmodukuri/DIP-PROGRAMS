# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 20:17:55 2019

@author: net comm0560
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as plt
img = cv2.imread('suk1.png',0)  
#cv2.imshow('pli',img) 

a=np.fft.fft2(img)
fshift = np.fft.fftshift(a)
magnitude_spectrum = 20*np.log(np.abs(fshift))
plt.subplot(2,2,1)
plt.imshow(magnitude_spectrum, cmap = 'gray')

b=np.fft.ifftshift(fshift)
m1 = 20*np.log(np.abs(b))
plt.subplot(2,2,2)
plt.imshow(m1, cmap = 'gray')


c=np.fft.ifft2(b)
m3 = 20*np.log(np.abs(c))
plt.subplot(2,2,3)
plt.imshow(m3, cmap = 'gray')

plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows() 



