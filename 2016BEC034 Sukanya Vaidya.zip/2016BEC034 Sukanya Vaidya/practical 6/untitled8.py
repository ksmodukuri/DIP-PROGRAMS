

import cv2
import numpy as np
import matplotlib.pyplot as plt

j = complex(0,1)

img = cv2.imread('C:\\Users\\net comm0560\\Desktop\\123\\gray.jpg',0)  # Input Image
plt.subplot(2,1,1)
plt.imshow(img , cmap = 'gray')
plt.title('Input Image')

img_FFT = np.fft.fft2(img)

mag = np.abs(img_FFT)
pha = np.angle(img_FFT)

print('Magnitude',mag)
print('Phase',pha)

pha = 0 # Phase = 0
out =  mag * np.e**(j*pha)
print(out)

out = np.fft.ifft2(out)
New_img = 20*np.log(np.abs(out))
print(New_img)

plt.subplot(2,1,2)
plt.imshow(New_img , cmap = 'gray')
plt.title('Image when Phase = 0')