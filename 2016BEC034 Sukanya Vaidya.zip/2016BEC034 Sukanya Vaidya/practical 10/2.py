

import cv2
from matplotlib import pyplot as plt
import numpy as np
imgg = cv2.imread("lena.jpg",0)
img = imgg[:,:,0]
mask_1 = np.array([[-1,0],[0,1]])
mask_2 = np.array([[0,1],[-1,0]])
blankimg = np.zeros([512,512])
for i in range(512):
    for j in range(512):
        mull = img[i:i+2,j:j+2]*mask_1
        blankimg[i][j] = np.sum(mull)    
plt.subplot(1,3,1)
plt.imshow(img,cmap='gray')
plt.title('Original Image')
plt.subplot(1,3,2)
plt.imshow(blankimg,cmap = 'gray')
plt.title('roberts X')
blankimg = np.zeros([512,512])
for i in range(512):
    for j in range(512):
        mull = img[i:i+2,j:j+2]*mask_2
        blankimg[i][j] = np.sum(mull)
plt.subplot(1,3,3)
plt.imshow(blankimg,cmap = 'gray')
plt.title('roberts Y')
