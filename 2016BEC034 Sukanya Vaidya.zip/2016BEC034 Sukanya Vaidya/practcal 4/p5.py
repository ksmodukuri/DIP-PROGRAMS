

import cv2

from matplotlib import pyplot as plt

img = cv2.imread(r'‪C:\Users\net comm0560\Desktop\123\gray.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


plt.imshow(img)
plt.show()

plt.hist(img.ravel(),256,[0,256])
plt.show()

cv2.waitKey()


