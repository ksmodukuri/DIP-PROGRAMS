


import cv2
import numpy as np
img = cv2.imread(r'C:\\Users\\net comm0560\\Desktop\\123\\gray.jpg')
cv2.imshow('original image',img)
temp = np.zeros(img.shape,img.dtype)
temp[:,:,0] = img[:,:,0]
cv2.imshow('Blue plane image',temp)

temp = np.zeros(img.shape,img.dtype)
temp[:,:,1] = img[:,:,1]
cv2.imshow('Green plane image',temp)
temp = np.zeros(img.shape,img.dtype)

temp[:,:,2] = img[:,:,2]

cv2.imshow('Red plane image',temp)

cv2.waitKey()
cv2.destroyAllWindows()