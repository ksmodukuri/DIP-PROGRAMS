

import cv2
from matplotlib import pyplot as plt
img = cv2.imread("lena.jpg",0)

img_1 = cv2.blur(img,(5,5))
plt.subplot(3,2,1)
plt.imshow(img,cmap = 'gray')
plt.title('Original Image')

plt.subplot(3,2,2)
plt.imshow(img_1,cmap = 'gray')
plt.title('Average')

gausian_blur = cv2.GaussianBlur(img,(5,5),0)

plt.subplot(3,2,3)
plt.imshow(gausian_blur,cmap='gray')
plt.title('Gausian')

median_blur = cv2.medianBlur(img,5)

plt.subplot(3,2,4)
plt.imshow(median_blur,cmap='gray')
plt.title('Median')
