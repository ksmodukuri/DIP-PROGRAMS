# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 23:10:13 2019

@author: net comm0560
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread(r"lena.png",0) 

img_1 = cv2.blur(img,(5,5)
plt.imshow(img,cmap = 'gray'
plt.title('Original Image')
plt.imshow(img_1,cmap = 'gray')
plt.title('Average filter')

gausian_blur = cv2.GaussianBlur(img,(5,5),0)

plt.imshow(img,cmap = 'gray')
plt.title('Original Image')

plt.subplot(324)
plt.imshow(gausian_blur,cmap='gray')
plt.title('Gausian blurred')

median_blur = cv2.medianBlur(img,5)
plt.subplot(325)
plt.imshow(img,cmap = 'gray')
plt.title('Original Image')

plt.imshow(median_blur,cmap='gray')
plt.title('Median blurred')
