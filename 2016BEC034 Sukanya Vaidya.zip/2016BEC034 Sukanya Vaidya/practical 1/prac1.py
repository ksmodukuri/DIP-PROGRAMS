# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 20:58:13 2019

@author: net comm0560
"""


import cv2

imagepath = r'C:\Users\net comm0560\Desktop\123\gray.jpg'

img = cv2.imread(imagepath)
cv2.imshow('Input Image',img)

print(img.shape)
print(img)

cv2.waitKey()
cv2.distroyAllWindows()