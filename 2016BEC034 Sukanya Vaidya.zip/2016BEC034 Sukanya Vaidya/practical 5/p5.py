

import cv2
import numpy as np
from matplotlib import pyplot as plt

imagepath = r'C:\Users\net comm0560\Desktop\123\1.jpg'
cv2.imshow('Input Image',img)

img = cv2.imread(imagepath,0)

z = np.zeros(256)
c = np.zeros(256)
print(img.shape)

for i in range (img.shape[0]):
    for j in range (img.shape[1]):
        k = img[i,j]
        z[k] = z[k] + 1
plt.plot(z)
plt.title('Histogram Without using function')
plt.show()


for i in range (256):  # Probablity of occurance
    for j in range (i+1):
        c[i]+= z[j]/(img.shape[0]*img.shape[1])
    c[i] = round(c[i]*255)


print(c)

c=c.astype(np.uint8) # converted to int
print(c)

for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        g=img[i,j]
        img[i,j]=c[g]

cv2.imshow('image',img)

cv2.waitKey()
# cv2.distroyAllWindows()
