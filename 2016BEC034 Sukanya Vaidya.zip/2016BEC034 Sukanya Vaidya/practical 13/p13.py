

import numpy as np
import cv2
import matplotlib.pyplot as plt

def a(small_patch,q):
    m = 16
    return np.mean(small_patch) - np.std(small_patch)*(np.sqrt(q/m-q))

def b(small_patch,q):
    m = 16
    if(np.std(small_patch)==0):
        return np.mean(small_patch)
    else:
        return np.mean(small_patch) + np.std(small_patch)*(np.sqrt(m-q/q))


img = cv2.imread("lena.png",0)
img = c; l=0;  m=0;  count = 0; k = 0
x = np.zeros(1024)
zoom= np.zeros([1024,1024])
for j in range(len(img)):
    for i in range(len(x)):
        x[i] = img[l][m]
        count=count+1
        if(count==(1024//len(img))):
            m=m+1
            count = 0
        if(m==len(img)):
            for b in range(1024//len(img)):
                zoom[k+b] = x
            x = np.zeros(1024)
            l=l+1
            m=0
            k+=1024//len(img)
plt.subplot(121)
plt.title("original image")
plt.imshow(img,cmap='gray')
plt.subplot(122)
plt.title("enlarged image")
plt.imshow(zoom,cmap='gray')
print('img= ',len(img));print('zoom image= ',len(zoom))

plt.subplot(121)
plt.title("original image")
plt.imshow(img,cmap='gray')

for i in range(128):
    for j in range(128):
        small_img = img[i*4:i*4+4,j*4:j*4+4]
        patch = small_img - np.mean(small_img)
        patch[patch >= 0] = 1
        patch[patch < 0] = 0
        q = 16 - np.count_nonzero(patch)
        patch[patch >= 0] = b(small_img,q)
        patch[patch < 0] = a(small_img,q)
        
        img[i*4:i*4+4,j*4:j*4+4] = patch

plt.subplot(122)
plt.title("original image")
plt.imshow(img,cmap='gray')

        