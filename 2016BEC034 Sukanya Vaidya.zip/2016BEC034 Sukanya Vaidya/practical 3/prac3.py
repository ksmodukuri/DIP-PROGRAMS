# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 21:09:31 2019

@author: net comm0560
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 19:36:09 2019

@author: DHANASHREE
"""

import cv2
import numpy as np

imagepath = r'C:\Users\DHANASHREE\Desktop\DIP PRACT\lena.jpg' # path of original image

img = cv2.imread(imagepath, 0)

cv2.imshow('Original Lena Image',img) # displaying original image

img_new = np.zeros(img.shape) # array for new image

 
for i in range (img.shape[0]):
    for j in range (img.shape[1]):
        if img[i,j]>=0 and img[i,j]<=63:
            img_new[i,j] = 0
        elif img[i,j]>=64 and img[i,j]<=122:
            img_new[i,j] = 80
        elif img[i,j]>=123 and img[i,j]<=191:
            img_new[i,j] = 160
        else:
            img_new[i,j] = 255
            
cv2.imshow('New image',img_new) # displaying new processed image 2



img_new_2 = np.zeros(img.shape,np.uint8)
 
for i in range (img.shape[0]):
    for j in range ( img.shape[1]):
        if img[i,j]<=100:
            img_new_2[i,j] = 0.5*img[i,j]
            
        elif img[i,j]>=100 and img[i,j]<=200:
            img_new_2[i,j] = (1.5*img[i,j])-100
            
        else:
            img_new_2[i,j] = img[i,j]

print('Original Image data type :',img.dtype)  # uint8
print('Processed Image data type :',img_new_2.dtype)  # float64

#img_new_2 = img_new_2.astype(np.uint8)  # Converting float64 to uint8

print('Processed Image data type :',img_new_2.dtype)  # uint8

cv2.imshow('Processed Image',img_new_2)   # displaying new processed image 3

cv2.waitKey()
cv2.distroyAllWindows()