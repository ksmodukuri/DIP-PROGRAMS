# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:05:45 2019

@author: net comm0560
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 11:38:27 2019

@author: net comm0560
"""

import cv2 
import numpy as np 
from matplotlib import pyplot as plt
img=cv2.imread("C:\\Users\\net comm0560\\Desktop\\123\\sstnew.jpg",0)
#plt.subplot(2,2,1) 
cv2.imshow('tower',img)

img1=cv2.imread("C:\\Users\\net comm0560\\Desktop\\123\\sukanyastar.png",0) 
#plt.subplot(2,2,2)
cv2.imshow('star',img1)
plt.show()

resized_image = cv2.resize(img1,(305,341))

cv2.imshow('star1',resized_image)
image_new=np.zeros(img.shape,np.uint8)
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
    
            image_new[i,j]=img[i,j]+resized_image[i,j]
            
cv2.imshow('new',image_new)
cv2.waitKey(0)




