# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 22:39:27 2019

@author: Mypc
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt 
img=cv2.imread("lenaa1.jpg",0)
img_new=np.zeros(img.shape)
cv2.imshow('lenaa1',img)
cv2.waitKey(0)
cv2.destroyAllWindow()
print(img.shape)
for i in range(0,225):
    for j in range(0,225):
        if img[i,j]<=127:
            img_new[i,j]=0
        else:
            img_new[i,j]=255
cv2.imwrite('lena.jpg',img_new)   
cv2.imshow('lena.jpg',img_new)
cv2.waitKey(0)
cv2.destroyAllWindow()
