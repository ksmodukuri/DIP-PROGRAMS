# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 22:43:46 2019

@author: Mypc
"""

import cv2
import numpy as np
img=cv2.imread("pout1.jpg",0)
cv2.imshow('pout1',img)
img_new=np.zeros(img.shape)
cv2.waitKey(0)
cv2.destroyAllWindow()
print(img.shape)
for i in range(0,247):
    for j in range(0,204):
        if img[i,j]>=0 and img[i,j]<=100:
            img_new[i,j]=0.5*img[i,j]
        elif img[i,j]>=101 and img[i,j]<=200:
            img_new[i,j]=1.5*img[i,j]
        else:
            img_new[i,j]=img[i,j] 
x=cv2.imread("p1.jpg") 
cv2.imshow('p1.jpg',x)
cv2.waitKey(0)
cv2.destroyAllWindow()
