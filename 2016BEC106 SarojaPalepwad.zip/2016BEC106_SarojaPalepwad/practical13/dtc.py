# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 23:05:57 2019

@author: Admin
"""

import numpy as np
import cv2
import matplotlib.pyplot as plt

def a(img,q):
    m = 16
    return np.mean(img) - np.std(img)*(np.sqrt(q/m-q))

def b(img,q):
    m = 16
    if(np.std(img)==0):
        return np.mean(img)
    else:
        return np.mean(img) + np.std(img)*(np.sqrt(m-q/q))


img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\dip\\lena (2).jpg",0)
plt.subplot(121)
plt.title("original image")
plt.imshow(img,cmap='gray')

for i in range(300):
    for j in range(300):
        img1 = img[i*4:i*4+4,j*4:j*4+4]
        dtc = img1 - np.mean(img1)
        dtc[dtc >= 0] = 1
        dtc[dtc < 0] = 0
        q = 16 - np.count_nonzero(dtc)
        dtc[dtc >= 0] = b(img1,q)
        dtc[dtc < 0] = a(img1,q)
        
        img[i*4:i*4+4,j*4:j*4+4] = dtc

plt.subplot(122)
plt.title("DTC image")
plt.imshow(img,cmap='gray')

        