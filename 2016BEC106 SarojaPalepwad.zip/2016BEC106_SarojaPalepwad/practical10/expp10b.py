# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 00:26:13 2019

@author: Admin
"""


import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\ghar\\check.jpg",0)
kernelx = np.array([[1,1,1],[0,0,0],[-1,-1,-1]])
kernely = np.array([[-1,0,1],[-1,0,1],[-1,0,1]])
prewittx = cv2.filter2D(img, -1, kernelx)
prewitty = cv2.filter2D(img, -1, kernely)
prewitt=((prewittx)**2+(prewitty)**2)**(1/2)
plt.subplot(221),plt.imshow(img, cmap = 'gray')
plt.title('Input Image')
plt.subplot(222),plt.imshow(prewittx, cmap = 'gray')
plt.title('Prewitt X')
plt.subplot(223),plt.imshow(prewitty, cmap = 'gray')
plt.title('Prewitt Y')
plt.subplot(224),plt.imshow(prewitt, cmap = 'gray')
plt.title('prewitt')