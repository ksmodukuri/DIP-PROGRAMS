# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 00:15:55 2019

@author: Admin
"""


import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\ghar\\check.jpg",0)
kernelx = np.array([[1,2,1],[0,0,0],[-1,-2,-1]])
kernely = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
sobelx = cv2.filter2D(img, -1, kernelx)  
sobely = cv2.filter2D(img, -1, kernely)  
sobel=((sobelx)**2+(sobely)**2)**(1/2)
plt.subplot(221),plt.imshow(img, cmap = 'gray')
plt.title('Input Image')
plt.subplot(222),plt.imshow(sobel, cmap = 'gray')
plt.title('Sobel')
plt.subplot(223),plt.imshow(sobelx, cmap = 'gray')
plt.title('Sobel X')
plt.subplot(224),plt.imshow(sobely, cmap = 'gray')
plt.title('Sobel Y')