# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 23:59:18 2019

@author: Admin
"""

import cv2
import matplotlib.pyplot as plt
img1 = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\photo\\black.jpg",0)
img2 = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\photo\\white.jpg",0)


ADD = cv2.add(img1,img2) 
plt.subplot(241)
plt.imshow(ADD,cmap='gray') 
plt.title("addition")
SUB= cv2.subtract(img1,img2)
plt.subplot(242)
plt.imshow(SUB,cmap='gray')
plt.title("subtraction")
MUL = img1*img2
plt.subplot(243)
plt.imshow(MUL,cmap='gray')
plt.title("multiplication")
div = img2/img1
plt.subplot(244)
plt.imshow(div,cmap='gray')
plt.title("division")
OR = cv2.bitwise_or(img1,img2)
plt.subplot(245)
plt.imshow(OR,cmap='gray')
plt.title("bitwise or")
AND = cv2.bitwise_and(img1,img2)
plt.subplot(246)
plt.imshow(AND,cmap='gray')
plt.title("bitwise and")
XOR = cv2.bitwise_xor(img1,img2)
plt.subplot(247)
plt.imshow(XOR,cmap='gray')
plt.title("bitwise xor")
NOT = cv2.bitwise_not(img1,img2)
plt.subplot(248)
plt.imshow(NOT,cmap='gray')
plt.title("bitwise not")
