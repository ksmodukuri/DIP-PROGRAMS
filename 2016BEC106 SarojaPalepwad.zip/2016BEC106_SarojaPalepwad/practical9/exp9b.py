# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 00:49:05 2019

@author: Admin
"""

import cv2
from matplotlib import pyplot as plt
import numpy as np
img1 = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\photo\\cam.jpg",0)
img= np.zeros([300,300])
mask = np.array([[1/9,1/9,1/9],[1/9,1/9,1/9],[1/9,1/9,1/9]])
img = np.pad(img,2,'constant')
b= np.zeros([300,300])
for i in range(300):
    for j in range(300):
        m= img[i:i+3,j:j+3]*mask
        b[i][j] = np.sum(m)    
plt.subplot(121)
plt.imshow(img,cmap='gray')
plt.title('Original Image')
plt.subplot(122)
plt.imshow(b,cmap = 'gray')
plt.title('Average Filter')


p=10*np.log10((255*255)/(1/(300*300)*np.sum(b-img)*np.sum(b-img)))
print('PSNR VALUE:',p)