# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 17:21:58 2019

@author: user
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt 
a = cv2.imread("checkerboard.jpg",0)
cv2.imshow("Board",a)
print(a.shape)
hist = cv2.calcHist([a],[0],None,[256],[0,255])
plt.subplot(311)
plt.plot(hist)
z=np.zeros(256)
for i in a:    
    for j in i:
        z[j]=z[j]+1
plt.subplot(312)
plt.plot(z)
for i in range(256):
    z[i]=z[i]/(256*256)
for i in range(256):
    z[i]=z[i]+z[i-1]
plt.subplot(313)
plt.plot(z)
