import cv2
import numpy as np
import matplotlib.pyplot as plt 
a = cv2.imread("checkerboard.jpg",0)
cv2.imshow("Board",a)
print(a.shape)
hist = cv2.calcHist([a],[0],None,[256],[0,255])
plt.subplot(321)
plt.plot(hist)
z=np.zeros(256)
for i in a:    
    for j in i:
        z[j]=z[j]+1
plt.subplot(322)
plt.plot(z)
r=np.rot90(a)
cv2.imshow("Boardrotate",r)
hist = cv2.calcHist([a],[0],None,[256],[0,255])
plt.subplot(323)
plt.plot(hist)
a = cv2.imread("black-white-horizontal-background.png",0)
cv2.imshow("blacknwhite",a)
print(a.shape)
hist = cv2.calcHist([a],[0],None,[256],[0,255])
plt.subplot(324)
plt.plot(hist)
r=np.rot90(a)
cv2.imshow("rotate",r)
hist = cv2.calcHist([a],[0],None,[256],[0,255])
plt.subplot(325)
plt.plot(hist)
cv2.waitKey(0)