# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 10:45:51 2019

@author: DSPLAB_USER
"""

import cv2
import matplotlib.pyplot as plt 
a=cv2.imread("lena.jpg",0)
cv2.imshow('lena',a)
b="lena.jpg"
cv2.imwrite(b,a)
print(a)
# =============================================================================
# x=plt.imread("E:\\python program\\dip1\\lenna.jpg",0)
# plt.imshow(x)
# =============================================================================
cv2.waitKey(0)
cv2.destroyAllWindows('lena')