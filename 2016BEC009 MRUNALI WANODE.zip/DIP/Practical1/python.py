# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 10:03:05 2019

@author: DSPLAB_USER
"""

print("Welcome To Python")

import numpy as np
a=np.array([1,2,3])
print(type(a))
print(a.shape)
print(a)

num=5
if num>0:
    print(num," is positive")
else:
    print(num," is negative")
 
def find_Evenodd(num): #odd or even 
    if (num%2==0):
        print(num," is even")
    else:
        print(num," is odd")
find_Evenodd(num) #function call

def factorial(num): #factorial
    fact=1
    for i in range(1, num+1):#for loop for finding factorial
        fact=fact*i
    return fact    #return factorial 
result=factorial(num)#function call and assign the value to variable result
print("The factorial of %d = %d"%(num,result))

x=4 #pattern
for i in range(1,x+1):
    for j in range(1,i+1):
        print("*",end="")
    print()
     
x=[[1 ,4], #transpose a matrix 
    [5 ,7]]
result=[[0,0],
         [0,0]]
for i in range(len(x)):   
   for j in range(len(x[0])):
       result[j][i] = x[i][j]
for r in result:
   print(r)    

arr = [[14, 17, 44],    #Summation of all elements in matrix
       [15, 6, 27],   
       [23, 2, 54]]   
print("\nSum of arr : ", np.sum(arr))

x=[[22 ,11], #multiplication of two matrix
    [13,32]]
y=[[13,12],
    [0,11]]
result=[[0,0],
         [0,0]]
for i in range(len(x)):
   for j in range(len(y[0])):
       for k in range(len(y)):
           result[i][j] += x[i][k]*y[k][j]
for r in result:
   print(r)
    
for j in range(1,11): #table 
    for k in range(1,11):
        print(j*k,end="\t")
    print("\n")

def fact(n): #factorial using recursion
    if n==0:
        return 1
    else:
        return n*fact(n-1)
n=4
result=fact(n)
print("factorial of",n,"is",result)
     
import numpy as np #Upper triangular matrix
b=np.random.randint(1,4,[3,3])       #multidimensional array
print(b)
for i in range(0,3):  
        for j in range(0, 3):  
            if(i > j):  
                print("0")
            else:  
               print(b[i][j])  
        print(" ")