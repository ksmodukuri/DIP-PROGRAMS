# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 01:16:34 2019

@author: user
"""

import cv2
import matplotlib.pyplot as plt
img1 = cv2.imread("black.png",0)
img2 = cv2.imread("white.png",0)
add = img1+img2

plt.subplot(341)
plt.imshow(img1,cmap='gray') ;plt.title("img1")
plt.subplot(342)
plt.imshow(img2,cmap='gray') ;plt.title("img2")
plt.subplot(343)
plt.imshow(add,cmap='gray') ;plt.title("addition")
sub = img2 - img1
plt.subplot(344)
plt.imshow(sub,cmap='gray');plt.title("subtraction")
mul = img1*img2
plt.subplot(345)
plt.imshow(mul,cmap='gray');plt.title("multiplication")
div = img2/img1
plt.subplot(346)
plt.imshow(div,cmap='gray');plt.title("division")
bor = cv2.bitwise_or(img1,img2)
plt.subplot(347)
plt.imshow(bor,cmap='gray');plt.title("bitwise or")
band = cv2.bitwise_and(img1,img2)
plt.subplot(348)
plt.imshow(band,cmap='gray');plt.title("bitwise and")
bxor = cv2.bitwise_xor(img1,img2)
plt.subplot(349)
plt.imshow(bxor,cmap='gray');plt.title("bitwise xor")
bnot = cv2.bitwise_not(img1,img2)
plt.subplot(3,4,10);plt.imshow(bnot,cmap='gray')
plt.title("bitwise not");plt.axis("off")
