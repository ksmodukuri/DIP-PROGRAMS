import numpy as np
import cv2
import matplotlib.pyplot as plt
img=cv2.imread(r"lena.png",0)
plt.subplot(221)
plt.imshow(img,cmap='gray');plt.axis('off');plt.title('Original image')
a=np.zeros((256,256))
for i in range(0,256):
    for j in range(0,256):
        a[i,j]=img[2*i,2*j]
        j=j+1
    i=i+1    
b=np.zeros((128,128))
for i in range(0,128):
    for j in range(0,128):
        b[i,j]=a[2*i,2*j]
        j=j+1
    i=i+1    
c=np.zeros((64,64))
for i in range(0,64):
    for j in range(0,64):
        c[i,j]=b[2*i,2*j]
        j=j+1
    i=i+1    
plt.subplot(222)
plt.imshow(c,cmap='gray');plt.axis('off');plt.title('shrink image 64*64')
print(c.shape[0],c.shape[1])
img = c;l=0;m=0;count = 0;k = 0
x = np.zeros(1024)
zoom= np.zeros([1024,1024])
for j in range(len(img)):
    for i in range(len(x)):
        x[i] = img[l][m]
        count=count+1
        if(count==(1024//len(img))):
            m=m+1
            count = 0
        if(m==len(img)):
            for b in range(1024//len(img)):
                zoom[k+b] = x
            x = np.zeros(1024)
            l=l+1
            m=0
            k=k+1024//len(img)
plt.subplot(223)
plt.title("original image")
plt.imshow(img,cmap='gray')
plt.subplot(224)
plt.title("zoom image")
plt.imshow(zoom,cmap='gray')
print('img= ',len(img));print('zoom image= ',len(zoom))
