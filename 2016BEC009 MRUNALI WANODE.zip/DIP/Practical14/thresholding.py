# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 09:37:24 2019

@author: DSPLAB_USER
"""

import cv2
from matplotlib import pyplot as plt
img = cv2.imread('thresh.jpg',0)
ret,th1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
th2 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_MEAN_C,\
            cv2.THRESH_BINARY,11,2)
ret2,th3 = cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
plt.subplot(2,2,1);plt.imshow(img,'gray');plt.title('Original image')
plt.subplot(2,2,2);plt.imshow(th1,'gray');plt.title('Global threshold image')
plt.subplot(2,2,3);plt.imshow(th2,'gray');plt.title('Adaptive threshold image')
plt.subplot(2,2,4);plt.imshow(th3,'gray');plt.title('Otsu threshold image')