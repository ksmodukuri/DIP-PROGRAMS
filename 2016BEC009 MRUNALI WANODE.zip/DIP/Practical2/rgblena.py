# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 14:17:18 2019

@author: COMPLAB_25
"""

import cv2
image = cv2.imread('lena.jpg') #original image
cv2.imshow('lena', image)
r = image.copy()
r[:, :, 1] = 0 # set green and blue channels to 0
r[:, :, 2] = 0
g = image.copy()
g[:, :, 0] = 0 # set red and blue channels to 0
g[:, :, 2] = 0
b = image.copy()
b[:, :, 0] = 0 # set red and green channels to 0
b[:, :, 1] = 0
cv2.imshow('R-RGB', r) # RGB - Red
cv2.imshow('G-RGB', g) # RGB - Green
cv2.imshow('B-RGB', b) # RGB - Blue
cv2.waitKey(0)