# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:58:46 2019

@author: user
"""

import numpy as np
import cv2
import math
img = cv2.imread('lena.jpg',0)
histogram = cv2.calcHist([img],[0],None,[256],[0,256])
total = np.sum(histogram)
final = 0
for i in range(256):
    p = histogram[i]/total
    if p != 0:
        final = final - p * math.log(p, 2)
    else:
        pass
print("Entropy is ",final[0])
