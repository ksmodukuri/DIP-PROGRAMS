# -*- coding: utf-8 -*-
"""
Created on Wed Aug 07 15:18:07 2019

@author: COMPLAB_25
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Aug 07 14:55:57 2019

@author: COMPLAB_25
"""

import cv2
import numpy as np
img= cv2.imread('lena.jpg',0)      
a=np.array(img)
n=len(img)
sum=0
def mean(n):
    global sum
    for i in range(0,n):
        for j in range(0,n):
           sum=sum+a[i,j]
mean(n)      
mean1=(sum/(204*204)) 
print("Mean=",mean1) 
m=np.mean(a)
print("Mean using command=",m)  
sum1=0
t=(img-m)**2
for i in range(t.shape[0]):
   for j in range(t.shape[1]):
       sum1=sum1+t[i,j]
var1=(sum1/(204*204))
print("Variance=",var1)
v=np.var(a)
print("Variance using command=",v)