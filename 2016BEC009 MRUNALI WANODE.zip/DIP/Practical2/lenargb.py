# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 10:27:11 2019

@author: DSPLAB_USER
"""

import cv2
import matplotlib.pyplot as plt 
a=cv2.imread("lena.jpg")
plt.subplot(1,4,1)
plt.imshow(a)
R=a[:,:,0]
plt.subplot(1,4,2)
plt.imshow(R)
G=a[:,:,1]
plt.subplot(1,4,3)
plt.imshow(G)
B=a[:,:,2]
plt.subplot(1,4,4)
plt.imshow(B)
cv2.waitKey(0)
#==============================================================================
# x=plt.imread("lena.jpg",0)
# plt.imshow(x)
# 
# b="lena.jpg"
# cv2.imwrite(b,a)
# print(a)
#==============================================================================