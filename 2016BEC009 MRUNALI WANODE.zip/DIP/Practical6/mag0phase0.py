import cv2
import numpy as np
import matplotlib.pyplot as plt

j = complex(0,1)

img = cv2.imread('lena1.jpg',0)  
#cv2.imshow('pli',img)
plt.subplot(1,3,1)
plt.imshow(img , cmap = 'gray')

img_FFT = np.fft.fft2(img)

mag = np.abs(img_FFT)
phase = np.angle(img_FFT)

print('Magnitude',mag)
print('Phase',phase)

phase = 0

out =  mag * np.e**(j*phase)
print(out)

out = np.fft.ifft2(out)
New_img = 20*np.log(np.abs(out))

print(New_img)

plt.subplot(1,3,2)
plt.imshow(New_img , cmap = 'gray')
plt.title("phase=0")

mag = 0
phase = np.angle(img_FFT)
out1 =  mag * np.e**(j*phase)
print(out1)

out1 = np.fft.ifft2(out1)
New_img1 = 20*np.log(np.abs(out1))

print(New_img1)

plt.subplot(1,3,3)
plt.imshow(New_img1 , cmap = 'gray')
plt.title("mag=0")