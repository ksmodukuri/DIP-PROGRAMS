# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 11:41:33 2019

@author: COMPLAB_25
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt 
a = cv2.imread("lena1.jpg",0)
plt.subplot(341)
plt.imshow(a,cmap='gray')
print(a.shape)
f=np.fft.fft2(a)
fshift1=np.fft.fftshift(f)
mag1=20*np.log(1+np.abs(fshift1))
plt.subplot(342)
plt.imshow(mag1,cmap='gray')
ishift=np.fft.ifftshift(fshift1)
b=np.fft.ifft2(ishift)
b=np.abs(b)
plt.subplot(343)
plt.imshow(b,cmap='gray')
c1=np.angle(fshift1)
plt.subplot(344)
plt.imshow(c1,cmap='gray')
a = cv2.imread("baboon.jpg",0)
plt.subplot(345)
plt.imshow(a,cmap='gray')
print(a.shape)
f=np.fft.fft2(a)
fshift=np.fft.fftshift(f)
mag2=20*np.log(1+np.abs(fshift))
plt.subplot(346)
plt.imshow(mag2,cmap='gray')
ishift=np.fft.ifftshift(fshift)
b=np.fft.ifft2(ishift)
b=np.abs(b)
plt.subplot(347)
plt.imshow(b,cmap='gray')
c2=np.angle(fshift)
plt.subplot(348)
plt.imshow(c2,cmap='gray')
out1 = np.abs(fshift1) * np.exp(1j*c2)#Recompute frequency responses by swapping the phases
out2 = np.abs(fshift) * np.exp(1j*c1)
out1 = np.fft.ifft2(out1)#Find the inverse images
out2 = np.fft.ifft2(out2)
plt.subplot(3,4,9)#Show the images
plt.imshow(abs(out1),cmap='gray')
plt.subplot(3,4,10)
plt.imshow(abs(out2),cmap='gray')
