# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 09:12:45 2019

@author: DSPLAB_USER
"""

import cv2
import numpy as np
a = cv2.imread('lena.jpg',0)
cv2.imshow('lenaimg',a)
print(a.shape)
a_new=np.zeros(a.shape)
for i in range(a.shape[0]):
    for j in range(a.shape[1]):
            if a[i,j]<64:
                a_new[i,j]=0
            elif a[i,j]>63 and a[i,j]<128:
                 a_new[i,j]=80
            elif a[i,j]>125 and a[i,j]<192:
                 a_new[i,j]=160
            else:
                a_new[i,j]=255
cv2.imwrite('lenanew.jpg',a_new)
b = cv2.imread('lenanew.jpg',0)
cv2.imshow('lenanew',b)
print(a_new)
a_new=np.zeros(a.shape)
for i in range(a.shape[0]):
    for j in range(a.shape[1]):
            if a[i,j]<128:
                a_new[i,j]=0            
            else:
                a_new[i,j]=255
cv2.imwrite('lenanew1.jpg',a_new)
b = cv2.imread('lenanew1.jpg',0)
cv2.imshow('lenanew1',b)
print(a_new)
cv2.waitKey(0)
