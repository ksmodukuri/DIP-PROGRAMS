# -*- coding: utf-8 -*-
"""
Created on Wed Aug 07 15:05:58 2019

@author: COMPLAB_25
"""

import cv2
import numpy as np
a = cv2.imread('pout.jpg',0)
cv2.imshow('poutimg',a)
print(a.shape)
a_new=np.zeros(a.shape)
for i in range(a.shape[0]):
    for j in range(a.shape[1]):
            if a[i,j]<101:
                a_new[i,j]=0.5*a[i,j]
            elif a[i,j]>99 and a[i,j]<201:
                 a_new[i,j]=1.5*a[i,j]-100
            else:
                a_new[i,j]=a[i,j]
cv2.imwrite('poutnew.jpg',a_new)
b = cv2.imread('poutnew.jpg',0)
cv2.imshow('poutnew',b)
print(a_new)