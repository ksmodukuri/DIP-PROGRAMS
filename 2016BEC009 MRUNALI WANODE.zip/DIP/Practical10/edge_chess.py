import cv2
import numpy as np
from matplotlib import pyplot as plt
img_blur = cv2.imread('checkerboard.png', 0)
kernelx = np.array([[1,2,1],[0,0,0],[-1,-2,-1]])
kernely = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])

sobelx = cv2.filter2D(img_blur, -1, kernelx)  
sobely = cv2.filter2D(img_blur, -1, kernely)  

kernelx = np.array([[1,1,1],[0,0,0],[-1,-1,-1]])
kernely = np.array([[-1,0,1],[-1,0,1],[-1,0,1]])

img_prewittx = cv2.filter2D(img_blur, -1, kernelx)
img_prewitty = cv2.filter2D(img_blur, -1, kernely)

kernelx = np.array([[-1,0],[0,1]])
kernely = np.array([[0,-1],[1,0]])

robert_x = cv2.filter2D(img_blur, -1, kernelx)
robert_y = cv2.filter2D(img_blur, -1, kernely)

prewitt=((img_prewittx)**2+(img_prewitty)**2)**(1/2)
sobel=((sobelx)**2+(sobely)**2)**(1/2)
robert=((robert_x)**2+(robert_y)**2)**(1/2)

plt.subplot(431),plt.imshow(img_blur, cmap = 'gray')
plt.title('Input Image')
plt.subplot(432),plt.imshow(img_prewittx, cmap = 'gray')
plt.title('Prewitt X')
plt.subplot(433),plt.imshow(img_prewitty, cmap = 'gray')
plt.title('Prewitt Y')
plt.subplot(434),plt.imshow(sobelx, cmap = 'gray')
plt.title('Sobel X')
plt.subplot(435),plt.imshow(sobely, cmap = 'gray')
plt.title('Sobel Y')
plt.subplot(436),plt.imshow(robert_x, cmap = 'gray')
plt.title('Robert X')
plt.subplot(437),plt.imshow(robert_y, cmap = 'gray')
plt.title('Robert Y')
plt.subplot(438),plt.imshow(prewitt, cmap = 'gray')
plt.title('Prewitt')
plt.subplot(439),plt.imshow(sobel, cmap = 'gray')
plt.title('Sobel')
plt.subplot(4,3,10),plt.imshow(robert, cmap = 'gray')
plt.title('Robert')
plt.show() 
