# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 19:06:07 2019

@author: one
"""

import cv2 
import numpy as np 
from matplotlib import pyplot as plt 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-4\\lena1.jpg",0) 
cv2.imshow('lena',img) 
b=cv2.calcHist([img],[0],None,[256],[0,256]) 
plt.subplot(2,2,1) 
plt.title("with command") 
plt.plot(b) 
b=np.zeros(256) 
for i in img: 
    for j in i: 
        b[j]=(b[j]+1) 
plt.subplot(2,2,2) 
plt.title('Without command Histogram') 
plt.plot(b)         
img1=np.rot90(img) 
plt.subplot(2,2,3) 
plt.imshow(img1)   
hist = cv2.calcHist([img1],[0],None,[256],[0, 256]) 
plt.subplot(2,2,4) 
plt.title("rotate hist") 
plt.plot(hist) 
cv2.waitKey(0)  
cv2.destroyAllWindows() 