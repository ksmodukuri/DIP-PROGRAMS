# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:00:01 2019

@author: one
"""

import cv2 
import numpy as np 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-2\\ip.jpg") 
#img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB) 
cv2.imshow('Original lena',img) 
t=np.zeros(img.shape,img.dtype) 
t[:,:,0]=img[:,:,0] 
cv2.imshow('blue plane image',t) 
t=np.zeros(img.shape,img.dtype) 
t[:,:,1]=img[:,:,1] 
cv2.imshow('Green Plane image',t) 
t=np.zeros(img.shape,img.dtype) 
t[:,:,2]=img[:,:,2] 
cv2.imshow('Red Plane image',t) 
cv2.waitKey(0) 
cv2.destroyAllWindows() 
 
 