# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:03:45 2019

@author: one
"""

import cv2 
import numpy as np 
img= cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-2\\lena.jpg") 
a=np.array(img) 
print(img.shape) 
tot=0 
for i in range(img.shape[0]): 
    for j in range(img.shape[1]): 
        for k in range(img.shape[2]): 
            tot=tot+img[(i,j,k)] 
m=tot/(204*204*3)     
print('mean=',m) 
m1=np.mean(a)        #using command 
print('mean1=',m1) 
v1=(img-m)**2   
tot1=0 
for i in range(img.shape[0]): 
    for j in range(img.shape[1]): 
        for k in range(img.shape[2]): 
            tot1=tot1+v1[(i,j,k)] 
v=tot1/((204*204*3)-1)         
print("Variance=",v) 
v1=np.var(a)                  #using command 
print("Variance1=",v1) 
cv2.waitKey(0) 
cv2.destroyAllWindows() 
 
