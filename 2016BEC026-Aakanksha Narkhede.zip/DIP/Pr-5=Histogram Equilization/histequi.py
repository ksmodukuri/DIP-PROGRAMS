# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 19:19:08 2019

@author: one
"""

import cv2  
import numpy as np  
from matplotlib import pyplot as plt 
img= cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-4\\1.PNG") 
cv2.imshow('Input Image',img) 
z = np.zeros(256) 
c = np.zeros(256) 
print(img.shape) 
for i in range (img.shape[0]): 
    for j in range (img.shape[1]): 
        k = img[i,j] 
        z[k] = z[k] + 1 
plt.plot(z) 
plt.title('Histogram Without using function') 
plt.show() 
histogram = cv2.calcHist([img], [0], None,[256], [0,256]) # Histogram using function 
plt.plot(histogram) 
plt.title('Histogram using Function') 
plt.show() 
 
for i in range (256):  # Probablity of occurance 
    c[i] = z[i]/(img.shape[0]*img.shape[1]) 
for i in range (255): 
    c[i] = c[i] + c[i-1] 
plt.plot(c) 
plt.title('CDF') 
plt.show() 
cv2.waitKey(0)  
cv2.destroyAllWindows() 