# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 21:04:39 2019

@author: one
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
img1= cv2.imread(" C:\\Users\\one\\Desktop\\DIP\\Pr-6\\prpgram\\lena.jpg",0)
img2= cv2.imread(" C:\\Users\\one\\Desktop\\DIP\\Pr-6\\prpgram\\babo.jpg",0)
plt.subplot(221),plt.imshow(img1, cmap = 'gray'),plt.axis("off")
plt.subplot(222),plt.imshow(img2, cmap = 'gray'),plt.axis("off")
a=np.fft.fft2(img1)
b=np.fft.fft2(img2)
new1=np.multiply(np.abs(a),np.exp(1j*np.angle(b)))
new2=np.multiply(np.abs(b),np.exp(1j*np.angle(a)))
new1=np.real(np.fft.ifft2(new1))
new2=np.real(np.fft.ifft2(new2))
plt.subplot(223),plt.imshow(np.abs(new1), cmap = 'gray'),plt.title('Mag1+phase2')
plt.axis("off")
plt.subplot(224),plt.imshow(np.abs(new2), cmap = 'gray'),plt.title('Mag2+phase1')
plt.axis("off")
cv2.waitKey()

