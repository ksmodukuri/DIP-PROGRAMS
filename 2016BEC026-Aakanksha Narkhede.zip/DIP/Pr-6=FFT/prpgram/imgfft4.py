# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 21:01:29 2019

@author: one
"""

import cv2 
import numpy as np 
from matplotlib import pyplot as plt 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-6\\14.png",0) 
plt.subplot(2,2,1)
plt.imshow(img, cmap = 'gray')
plt.title('Input Image')
f = np.fft.fft2(img)
fshift = np.fft.fftshift(f)
magnitude_spectrum = 20*np.log(np.abs(fshift))
plt.subplot(2,2,2)
plt.imshow(magnitude_spectrum,cmap = 'gray')
plt.title('fftshift')
a=np.fft.ifftshift(fshift)
b=20*np.log(np.abs(a))
plt.subplot(2,2,3)
plt.imshow(b,cmap = 'gray')
plt.title('ifftshift')
c = np.fft.ifft2(a)
d=20*np.log(np.abs(c))
plt.subplot(2,2,4)
plt.imshow(d,cmap = 'gray')
plt.title('ifft')
plt.show()
cv2.waitKey(0)  
cv2.destroyAllWindows()
