# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 18:38:12 2019

@author: one
"""

import cv2 
import numpy as np 
img1= cv2.imread("C:\\Users\\one\\Desktop\\python practical\\arith\\3.jpg",0)
img2= cv2.imread("C:\\Users\\one\\Desktop\\python practical\\arith\\4.jpg",0) 

img=np.zeros(img1.shape,np.uint8)
for i in range(img1.shape[0]):
    for j in range(img1.shape[1]):
        img[i,j]=img1[i,j]+img2[i,j]
            
cv2.imshow('lena',img1)
cv2.imshow('baboon',img2)
cv2.imshow('Adter adding',img)
cv2.waitKey(0) 
cv2.destroyAllWindows() 



"""
import cv2 
import numpy as np 
import matplotlib.pyplot as plt
img1= cv2.imread("C:\\Users\\one\\Desktop\\python practical\\arith\\3.jpg")
a= np.array(img1) 
print(img1.shape)
img2= cv2.imread("C:\\Users\\one\\Desktop\\python practical\\arith\\4.jpg") 
b= np.array(img2) 
cv2.imshow('bW',img1)
cv2.imshow('bW1',img2)
img= cv2.add(a,b)
cv2.imshow('Addition',img)

cv2.waitKey(0) 
cv2.destroyAllWindows() 
"""