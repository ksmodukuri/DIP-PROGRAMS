# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 11:12:34 2019

@author: one
"""

import cv2  
import numpy as np  
import matplotlib.pyplot as plt 
img1= cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-11\\1.png",0) 
img2= cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-11\\2.png",0) 
a= np.array(img1)   
b= np.array(img2)  
cv2.imshow('bW',img1) 
cv2.imshow('bW1',img2) 
and1 = cv2.bitwise_and(img1,img2) 
orr = cv2.bitwise_or(img1,img2) 
xor = cv2.bitwise_xor(img1,img2) 
not1 = cv2.bitwise_not(img1,img2) 
cv2.imshow('bitwise-AND',and1) 
cv2.imshow('bitwise-OR',orr) 
cv2.imshow('bitwise-XOR',xor) 
cv2.imshow('bitwise-NOT',not1) 
cv2.waitKey(0)  
cv2.destroyAllWindows() 