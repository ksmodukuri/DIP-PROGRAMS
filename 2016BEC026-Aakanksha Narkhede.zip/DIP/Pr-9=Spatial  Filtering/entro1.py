# -*- coding: utf-8 -*-
"""
Created on Wed oct  2 20:55:31 2019

@author: one
"""

import cv2 
from matplotlib import pyplot as plt 
import numpy as np 
img = cv2.imread("C:\\Users\\one\\Desktop\\python practical\\arith\\lena1.png",0) 
kernel = np.array(([1,1,1],[1,1,1],[1,1,1]))
kernel = 1.0/9.0*kernel
mean = cv2.filter2D(img,-1,kernel)
median = cv2.medianBlur(img,3)       #going wd 3*3kernel size
g_low = cv2.GaussianBlur(img,(3,3),0)
plt.subplot(221),plt.imshow(img,cmap='gray'),plt.title('Original')
plt.xticks([]),plt.yticks([])
plt.subplot(222),plt.imshow(mean,cmap='gray'),plt.title('Mean')
plt.xticks([]),plt.yticks([])
plt.subplot(223),plt.imshow(median,cmap='gray'),plt.title('Median')
plt.xticks([]),plt.yticks([])
plt.subplot(224),plt.imshow(g_low,cmap='gray'),plt.title('Gaussian')
plt.xticks([]),plt.yticks([])
plt.show()
