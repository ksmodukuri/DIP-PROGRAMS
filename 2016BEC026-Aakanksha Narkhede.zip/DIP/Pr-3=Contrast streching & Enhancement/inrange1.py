# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:08:15 2019

@author: one
"""

import cv2 
import numpy as np 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-3\\ip.jpg",0) 
t=np.zeros(img.shape) 
cv2.imshow('graylena',img) 
for r in range(255): 
    for c in range(255): 
        if img[r,c] >= 0 and img[r,c] <= 63: 
            t[r,c]=0 
        elif img[r,c] >= 64 and img[r,c] <= 122: 
            t[r,c]=80 
        elif img[r,c] >= 123 and img[r,c] <= 191: 
            t[r,c]=160 
        elif img[r,c] >= 192 and img[r,c] <= 255: 
            t[r,c]=255 
cv2.imwrite('lena.jpg',t) 
n=cv2.imread("lena.jpg") 
cv2.imshow('lena.jpg',n)             
cv2.waitKey(0) 
cv2.destroyAllWindows() 