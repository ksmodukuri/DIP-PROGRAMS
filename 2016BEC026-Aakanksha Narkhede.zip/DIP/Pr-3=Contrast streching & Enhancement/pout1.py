# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:19:41 2019

@author: one
"""

import cv2 
import numpy as np 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-3\\pout.jpg",0) 
t=np.zeros(img.shape,np.uint8) 
cv2.imshow('pout1',img) 
for r in range(img.shape[0]): 
    for c in range(img.shape[1]): 
        if img[r,c] >= 0 and img[r,c] <= 100: 
            t[r,c]=0.5*img[r,c] 
        elif img[r,c] >= 100 and img[r,c] <= 200: 
            t[r,c]=1.5*img[r,c]-100 
        else: 
            t[r,c]=img[r,c] 
cv2.imshow('new-img',t) 
cv2.waitKey(0) 
cv2.destroyAllWindows() 