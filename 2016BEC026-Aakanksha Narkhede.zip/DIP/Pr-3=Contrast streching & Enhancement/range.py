# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 20:11:48 2019

@author: one
"""

import cv2 
import numpy as np 
from matplotlib import pyplot as plt 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-3\\ip.jpg",0) 
t=np.zeros(img.shape) 
cv2.imshow('graylena',img) 
for r in range(256): 
    for c in range(256): 
        if img[r,c]<=127: 
            t[r,c]=0 
        else: 
            t[r,c]=255 
 
cv2.imshow('new-img',t)             
cv2.waitKey(0) 
cv2.destroyAllWindows() 