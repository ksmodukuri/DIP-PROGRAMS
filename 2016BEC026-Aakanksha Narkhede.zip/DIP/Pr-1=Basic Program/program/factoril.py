# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:31:57 2019

@author: one
"""

num=int(input("Enter a number: ")) 
fact=1 
if num==0:    
    print("Factorial of 0 is 1") 
else:     
    for i in range(1,num+1):      
        fact=fact*i     
    print("Factorial of number is=",fact) 