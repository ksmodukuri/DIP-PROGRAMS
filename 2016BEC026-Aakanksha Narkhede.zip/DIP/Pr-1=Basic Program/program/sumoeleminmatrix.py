# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:37:31 2019

@author: one
"""

import numpy as np
sum = 0
b=np.random.randint(1,5,[3,3]) 
print(b)   
for i in range(0,3):     
    for j in range(0,3):          
        sum += b[i][j]    
    print("Sum of the row",i,"=",sum)  
 