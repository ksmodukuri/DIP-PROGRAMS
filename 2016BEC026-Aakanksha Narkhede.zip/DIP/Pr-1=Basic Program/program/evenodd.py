# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:30:50 2019

@author: one
"""

num=int(input("Enter a number: ")) 
if(num%2)==0:    
    print("{0} is Even".format(num))
else:    
    print("{0} is Odd".format(num)) 