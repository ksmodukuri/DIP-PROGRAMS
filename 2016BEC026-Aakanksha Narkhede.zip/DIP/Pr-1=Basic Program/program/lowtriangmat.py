# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:44:21 2019

@author: one
"""

import numpy as np 
b=np.random.randint(1,5,[3,3]) 
print(b) 
for i in range(0,3):    
    for j in range(0,3):      
        if(i<j):           
            print("0",end=" ");     
        else:            
            print(b[i][j],end=" ");   
    print(" ");       