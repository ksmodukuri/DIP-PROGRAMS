# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:20:32 2019

@author: one
"""

num=int(input("Enter a number: ")) 
if num>0:    
    print("Positive Number") 
elif num==0:    
    print("zero") 
else:    
    print("Negative Number")     