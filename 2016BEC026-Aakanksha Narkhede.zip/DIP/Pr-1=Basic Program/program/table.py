# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:45:37 2019

@author: one
"""

for i in range(1,11):   
    for j in range(1,11):       
        print(i*j,end="\t")   
    print("\n")   