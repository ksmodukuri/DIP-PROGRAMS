# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:34:22 2019

@author: one
"""

import numpy as np 
a=np.array(([1,2],[3,4],[5,6]))
print("a=",a) 
b=np.array(([0,0,0],[0,0,0])) 
print("b=",b) 
#for Rows 
for i in range(len(a)):    
#for colums     
    for j in range(len(a[0])):     
        b[j][i]=a[i][j]
for r in b: 
    print("r=",r) 
            
 