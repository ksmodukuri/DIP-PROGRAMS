# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:33:32 2019

@author: one
"""

def pypart(n):  
 for i in range(0, n):  
  for j in range(0, i+1):  
   print("* ",end="")  
  print("\r")  
n = 5 
pypart(n) 