# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:40:25 2019

@author: one
"""

import numpy as np 
a=np.array(([1,2,3],[3,4,5],[5,6,7])) 
print("a=",a) 
b=np.array(([5,8,1,2],[6,7,3,0],[4,5,9,1]))
print("b=",b) 
c=np.zeros([3,4]) 
print("c=",c) 
for i in range(len(a)):   
    for j in range(len(b[0])):     
        for k in range(len(b)):         
            c[i][j]+=a[i][k]*b[k][j]
for r in c:    
    print(r)