# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 19:50:00 2019

@author: one
"""

import cv2 
import matplotlib.pyplot as plt 
img=cv2.imread("C:\\Users\\one\\Desktop\\DIP\\Pr-1\\lena1.jpg") 
print(img[100,100]) 
r,c,d = img.shape[0:3] 
print(img.size) 
print(img.dtype) 
cv2.imshow('Lena Image',img) 
plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB)) 