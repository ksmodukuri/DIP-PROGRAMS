# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 17:19:46 2019

@author: DHANASHREE
"""


import cv2

# import numpy library as np
import numpy as np

# read an image using imread() function of cv2
# we have to  pass only the path of the image
img = cv2.imread(r'C:\Users\DHANASHREE\Desktop\DIP PRACT\lena.jpg')

# displaying the image using imshow() function of cv2
# In this : 1st argument is name of the frame
# 2nd argument is the image matrix
cv2.imshow('original image',img)

# shape attribute of an image matrix gives the dimensions

# here image is of class 'uint8', the range of values  
# that each colour component can have is [0 - 255]

# create a zero matrix of order same as
# original image matrix order of same dimension
temp = np.zeros(img.shape,img.dtype)

# store blue plane contents or data of image matrix
# to the corresponding plane(blue) of temp matrix
temp[:,:,0] = img[:,:,0]

# displaying the Blue plane image
cv2.imshow('Blue plane image',temp)


# # again take a zero matrix of image matrix shape
temp = np.zeros(img.shape,img.dtype)
# 
# # store green plane contents or data of image matrix
# # to the corresponding plane(green) of temp matrix
temp[:,:,1] = img[:,:,1]
# 
# # displaying the Green plane image
cv2.imshow('Green plane image',temp)
# 
# # again take a zero matrix of image matrix shape
temp = np.zeros(img.shape,img.dtype)
# 
# # store red plane contents or data of image matrix
# # to the corresponding plane(red) of temp matrix
temp[:,:,2] = img[:,:,2]
# 
# # displaying the Red plane image
cv2.imshow('Red plane image',temp)

cv2.waitKey()
cv2.destroyAllWindows()