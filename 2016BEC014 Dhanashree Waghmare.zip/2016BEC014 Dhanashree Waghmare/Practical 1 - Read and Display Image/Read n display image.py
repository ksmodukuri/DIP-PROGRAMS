# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 21:18:35 2019

@author: DHANASHREE
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 09:14:05 2019

@author: DHANASHREE
"""

import cv2

imagepath = 'C:\\Users\\DHANASHREE\\Desktop\\DIP PRACT\\lena.jpg'

img = cv2.imread(imagepath)
cv2.imshow('Input Image',img)

print(img.shape)
print(img)

cv2.waitKey()
cv2.distroyAllWindows()