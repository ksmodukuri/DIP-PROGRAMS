# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 23:22:41 2019

@author: DHANASHREE
"""

import cv2
import matplotlib.pyplot as plt

img1 = cv2.imread(r"C:\Users\DHANASHREE\Desktop\DIP PRACT\1.png",0)
img2 = cv2.imread(r"C:\Users\DHANASHREE\Desktop\DIP PRACT\12.png",0)

add = img1+img2
plt.subplot(4,2,1)
plt.imshow(add,cmap='gray') 
plt.title("addition")

sub = img1 - img2
plt.subplot(4,2,2)
plt.imshow(sub,cmap='gray')
plt.title("subtraction")

mul = img1*img2
plt.subplot(4,2,3)
plt.imshow(mul,cmap='gray')
plt.title("multiplication")


div = img1/img2
plt.subplot(4,2,4)
plt.imshow(div,cmap='gray')
plt.title("division")

OR = cv2.bitwise_or(img1,img2)
plt.subplot(4,2,5)
plt.imshow(OR,cmap='gray')
plt.title("bitwise or")

AND = cv2.bitwise_and(img1,img2) 
plt.subplot(4,2,6)
plt.imshow(AND,cmap='gray')
plt.title("bitwise and")

XOR = cv2.bitwise_xor(img1,img2) 
plt.subplot(4,2,7)
plt.imshow(XOR,cmap='gray')
plt.title("bitwise xor")

NOT = cv2.bitwise_not(img1,img2) 
plt.subplot(4,2,8)
plt.imshow(NOT,cmap='gray')
plt.title("bitwise not")
