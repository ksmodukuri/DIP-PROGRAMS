# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 21:53:45 2019

@author: DHANASHREE
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('C:\\Users\\DHANASHREE\\Desktop\\DIP PRACT\\lena.jpg',0)  # Input Image
plt.subplot(2,2,1)
plt.imshow(img,cmap = 'gray')
plt.title('Input Image')

a = np.fft.fft2(img) # Fourier Transform
fshift = np.fft.fftshift(a)
magnitude_spectrum = 20*np.log(np.abs(fshift))
plt.subplot(2,2,2)
plt.imshow(magnitude_spectrum,cmap = 'gray')
plt.title('Fourier Transform')

b = np.fft.ifftshift(fshift) # Inverse Fourier Transform
m1 = 20*np.log(np.abs(b))
plt.subplot(2,2,3)
plt.imshow(m1,cmap = 'gray')
plt.title('Inverse Fourier Transform')

c = np.fft.ifft2(b) # Recovering Image Back
m3 = 20*np.log(np.abs(c))
plt.subplot(2,2,4)
plt.imshow(m3,cmap = 'gray')
plt.title('Recovered Image')

plt.show()

cv2.waitKey(0)
