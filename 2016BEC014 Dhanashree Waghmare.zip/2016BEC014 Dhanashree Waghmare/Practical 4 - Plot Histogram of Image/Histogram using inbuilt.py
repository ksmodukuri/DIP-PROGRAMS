# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 14:30:49 2019

@author: COMPLAB_12
"""

import cv2

from matplotlib import pyplot as plt

img = cv2.imread(r'C:\Users\DHANASHREE\Desktop\DIP PRACT\lena.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


plt.imshow(img)
plt.show()

plt.hist(img.ravel(),256,[0,256])
plt.show()

cv2.waitKey()


