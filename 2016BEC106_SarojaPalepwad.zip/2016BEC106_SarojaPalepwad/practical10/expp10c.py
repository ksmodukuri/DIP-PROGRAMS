# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 00:33:27 2019

@author: Admin
"""


import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\ghar\\check.jpg",0)

kernelx = np.array([[-1,0],[0,1]])
kernely = np.array([[0,-1],[1,0]])

robertx = cv2.filter2D(img, -1, kernelx)
roberty = cv2.filter2D(img, -1, kernely)

robert=((robertx)**2+(roberty)**2)**(1/2)

plt.subplot(221),plt.imshow(img, cmap = 'gray')
plt.title('Input Image')

plt.subplot(222),plt.imshow(robertx, cmap = 'gray')
plt.title('robert X')
plt.subplot(223),plt.imshow(roberty, cmap = 'gray')
plt.title('Robert Y')
plt.subplot(224),plt.imshow(robert, cmap = 'gray')
plt.title('Robert')
plt.show()
