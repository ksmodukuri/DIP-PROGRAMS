# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 22:42:05 2019

@author: Mypc
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt 
img=cv2.imread('lenaa1.jpg',0)
img_new=np.zeros(img.shape)
cv2.imshow('lenaa1',img)
cv2.waitKey(0)
cv2.destroyAllWindow()
print(img.shape)
for i in range(0,225):
    for j in range(0,225):
        if img[i,j]>=0 and img[i,j]<=63:
            img_new[i,j]=0
        elif img[i,j]>=64 and img[i,j]<=122:
            img_new[i,j]=80	
        elif img[i,j]>=123 and img[i,j]<=191:
            img_new[i,j]=160
        elif img[i,j]>=192 and img[i,j]<=255:
            img_new[i,j]=255
x=cv2.imread('lena.jpg') 
cv2.imshow('lena.jpg',x)
cv2.waitKey(0)
cv2.destroyAllWindow()
