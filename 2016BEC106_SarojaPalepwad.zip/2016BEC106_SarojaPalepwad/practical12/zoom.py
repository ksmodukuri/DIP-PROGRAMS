# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 22:39:33 2019

@author: Admin
"""

import numpy as np
import cv2
import matplotlib.pyplot as plt

img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\dip\\lena (2).jpg",0)
z= np.zeros([300,300])
img1 = np.zeros([len(img)//2,len(img)//2])            #shrinked image

l=0
for i in range(0,len(img),2):
    m=0
    for j in range(0,len(img),2):
        img1[l][m] = img[i][j]
        m+=1
    l+=1

plt.subplot(221)
plt.title("original image")
plt.imshow(img,cmap='gray')
plt.subplot(222)
plt.title("shrinked image")
plt.imshow(img1,cmap='gray')
l=0
m=0
count= 0
k = 0
z1= np.zeros(300)

#for j in range(len(img)):
#    for i in range(len(z1)):
#        z1[i] = img[l][m]
#        count+=1
#        if(count==(300//len(img))):
#            m+=1
#            count = 0
#        if(m==len(img)):
#            for b in range(300//len(img)):
#                z[k+b] = z1
#            z1 = np.zeros(300)
#            l+=1
#            m=0
#            k+=300//len(img)
#plt.subplot(223)
#plt.title("zoomed image")
#plt.imshow(z,cmap='gray')