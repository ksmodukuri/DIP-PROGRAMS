# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 00:48:10 2019

@author: Admin
"""

import cv2
from matplotlib import pyplot as plt
import numpy as np
imgg = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\photo\\cam.jpg",0)
img = imgg[:,:,0]
mask = np.array([[1/25,1/25,1/25,1/25,1/25],[1/25,1/25,1/25,1/25,1/25],[1/25,1/25,1/25,1/25,1/25],[1/25,1/25,1/25,1/25,1/25],[1/25,1/25,1/25,1/25,1/25]])
img = np.pad(img,2,'constant')
z= np.zeros([300,300])
for i in range(300):
    for j in range(300):
            v= img[i:i+5,j:j+5]*mask
            z[i][j] = np.min(v)      
            plt.subplot(131)
            plt.imshow(img,cmap='gray')
            plt.title('Original Image')
            plt.subplot(132)
            plt.imshow(z,cmap = 'gray')
            plt.title('Min Filter')
            z= np.zeros([300,300])
for i in range(300):
    for j in range(300):
            v = img[i:i+5,j:j+5]*mask
            z[i][j] = np.max(v)
            plt.subplot(133)
            plt.imshow(z,cmap = 'gray')
            plt.title('Max Filter')
