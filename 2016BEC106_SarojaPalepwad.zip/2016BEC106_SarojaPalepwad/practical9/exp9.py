# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 00:43:45 2019

@author: Admin
"""
#done
import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread("C:\\Users\\Admin\\Desktop\\practicals\\DIP\\ghar\\mona.jpg",0)
img1 = cv2.blur(img,(5,5))
plt.subplot(321)
plt.imshow(img,cmap = 'gray')
plt.title('Original Image')
plt.subplot(322)
plt.imshow(img1,cmap = 'gray')
plt.title('Average filter')
gausian_blur = cv2.GaussianBlur(img,(5,5),0)
plt.subplot(323)
plt.imshow(gausian_blur,cmap='gray')
plt.title('Gausian blurred')
median_blur = cv2.medianBlur(img,5)
plt.subplot(324)
plt.imshow(median_blur,cmap='gray')
plt.title('Median blurred')


p1=10*np.log10((255*255)/(1/(300*300)*np.sum(gausian_blur)*np.sum(gausian_blur)))
print('PSNR VALUE gaussian:',p1)

p2=10*np.log10((255*255)/(1/(300*300)*np.sum(median_blur)*np.sum(median_blur)))
print('PSNR VALUE median:',p2)

p3=10*np.log10((255*255)/(1/(300*300)*np.sum(img1)*np.sum(img1)))
print('PSNR VALUE average:',p3)
